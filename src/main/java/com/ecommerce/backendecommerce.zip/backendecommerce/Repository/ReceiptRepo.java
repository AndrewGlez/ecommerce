package com.ecommerce.backendecommerce.Repository;

import com.ecommerce.backendecommerce.Entitys.Receipt;
import org.springframework.data.repository.CrudRepository;

public interface ReceiptRepo extends CrudRepository<Receipt, Integer> {
}
