package com.ecommerce.backendecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendEcommerceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendEcommerceApplication.class, args);
    }

}
