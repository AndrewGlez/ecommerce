package com.ecommerce.backendecommerce.Service;

import com.ecommerce.backendecommerce.Entitys.User;
import com.ecommerce.backendecommerce.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    public UserRepo userRepository;

    public Iterable<User> findAll() {
        return userRepository.findAll();
    }
    public Optional<User> findById(int id) {
        return userRepository.findById(id);
    }
    public User save(User user) {
        return userRepository.save(user);
    }
    public User update(User user) {
        User currentUser = userRepository.findById(user.getId()).get();
        currentUser.setFirstName(user.getFirstName());
        currentUser.setLastName(user.getLastName());
        currentUser.setEmail(user.getEmail());
        currentUser.setAddress(user.getAddress());
        currentUser.setPhoneNumber(user.getPhoneNumber());
        return userRepository.save(currentUser);
    }
    public void deleteById(int id) {
        userRepository.deleteById(id);
    }

    public User registerUser(Integer userId, String firstName, String lastName, String email, String password,
                             String address, String phoneNumber) {

        User newUser = new User(userId, firstName, lastName, email, password, address, phoneNumber);
        try {
            return userRepository.save(newUser);
        } catch (Exception e) {
            throw new RuntimeException("El usuario ya existe");
        }
    }

    public User registerUser(String firstName, String lastName, String email, String password,
                             String address, String phoneNumber) {

        User newUser = new User(firstName, lastName, email, password, address, phoneNumber);
        try {
            return userRepository.save(newUser);
        } catch (Exception e) {
            throw new RuntimeException("El usuario ya existe");
        }
    }

    // Login
    public User loginUser(String email, String password) {
        User userToLogin = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        if (!userToLogin.getPassword().equals(password)) {
            throw new RuntimeException("Credenciales inválidas");

        }
        return userToLogin;
    }
}
