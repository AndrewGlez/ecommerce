package com.ecommerce.backendecommerce.Controller;

import com.ecommerce.backendecommerce.Entitys.User;
import com.ecommerce.backendecommerce.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:5173")

@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public Iterable<User> getUsers() {
        return userService.findAll();
    }
    @RequestMapping( value = "/{id}",method = RequestMethod.GET, produces = "application/json")
    public Optional<User> getUserById(@PathVariable int id) {
        return userService.findById(id);
    }
    @RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json")
    public User createUser(User user) {
        return userService.save(user);
    }
    @RequestMapping(value = "/update", method = RequestMethod.PUT, produces = "application/json")
    public User updateUser(User user) {
        return userService.update(user);
    }
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE, produces = "application/json")
    public void deleteUser(@PathVariable int id) {
        userService.deleteById(id);
    }
    @PostMapping("/register")
    public User register(@RequestBody LinkedHashMap<String, String> body) {
        String firstName = body.get("first_name");
        String lastName = body.get("last_name");
        String email = body.get("email");
        String password = body.get("password");
        String address = body.get("address");
        String phoneNumber = body.get("phone_number");
        return userService.registerUser(firstName, lastName, email, password, address, phoneNumber);
    }

    @PostMapping("/login")
    public User login(@RequestBody LinkedHashMap<String, String> body) {
        String email = body.get("email");
        String password = body.get("password");
        return userService.loginUser(email, password);
    }
}
